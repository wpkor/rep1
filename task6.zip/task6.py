import csv
import json

visit_log_file = 'visit_log__1___2_.csv'
purchase_log_file = 'purchase_log.txt'
funnel_file = 'funnel.csv'

purchases_dict = {}

with open(purchase_log_file, encoding='utf-8') as f:
    next(f)  
    for line in f:
        data = json.loads(line.strip())
        purchases_dict[data['user_id']] = data['category']

with open(visit_log_file, encoding='utf-8') as f_visits, open(funnel_file, 'w', encoding='utf-8',
                                                              newline='') as f_funnel:
    reader = csv.reader(f_visits)
    writer = csv.writer(f_funnel)

    writer.writerow(['user_id', 'source', 'category'])

    next(reader)
    for row in reader:
        user_id, source = row
        if user_id in purchases_dict:
            writer.writerow([user_id, source, purchases_dict[user_id]])  

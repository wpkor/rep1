import json
import xml.etree.ElementTree as ET

def read_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)

def json_to_xml(data):
    root = ET.Element("people")

    for person in data:
        person_elem = ET.SubElement(root, "person")

        for key, value in person.items():
            child = ET.SubElement(person_elem, key)
            child.text = str(value)

    tree = ET.ElementTree(root)
    return tree
def save_xml(tree, file_path):
    tree.write(file_path, encoding="utf-8", xml_declaration=True)
def convert_json_to_xml(json_file, xml_file):
    data = read_json(json_file)
    xml_tree = json_to_xml(data)
    save_xml(xml_tree, xml_file)
    print(f"Данные успешно сконвертированы и сохранены в {xml_file}")
json_file = "data.json"
xml_file = "data.xml"
convert_json_to_xml(json_file, xml_file)
